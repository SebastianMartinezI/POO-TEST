package co.edu.uniquindio.poo.model;

public enum Estado {
    DISPONIBLE,
    PRESTADO
}

