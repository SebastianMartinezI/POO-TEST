module co.edu.uniquindio.poo.proyectobiblioteca {
        requires javafx.controls;
        requires javafx.fxml;

        opens co.edu.uniquindio.poo.proyectobiblioteca to javafx.fxml;
        exports co.edu.uniquindio.poo.proyectobiblioteca;
        exports co.edu.uniquindio.poo.proyectobiblioteca.viewController;
        opens co.edu.uniquindio.poo.proyectobiblioteca.viewController to javafx.fxml;

        }