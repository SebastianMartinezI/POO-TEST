package co.edu.uniquindio.poo.proyectobiblioteca.controller;

import co.edu.uniquindio.poo.proyectobiblioteca.model.*;

import java.util.List;

/**
 * Controlador para gestionar las operaciones del Bibliotecario en el sistema.
 * Esta clase actúa como intermediario entre la interfaz de usuario y la lógica
 * de negocio relacionada con la gestión de libros, usuarios y préstamos.
 * Permite realizar operaciones como registro de libros, usuarios, gestión de
 * préstamos y devoluciones.
 */
public class BibliotecarioController {
    private final Bibliotecario bibliotecario;

    /**
     * Constructor del controlador de Bibliotecario.
     *
     * @param bibliotecario La instancia del bibliotecario que realizará las operaciones
     */
    public BibliotecarioController(Bibliotecario bibliotecario) {
        this.bibliotecario = bibliotecario;
    }


    /**
     * Registra un nuevo libro físico en el sistema.
     *
     * @param libro El libro físico a registrar
     */
    public void registrarLibroFisico(LibroFisico libro) {
        bibliotecario.registrarLibroFisico(libro);
    }

    /**
     * Registra un nuevo libro digital en el sistema.
     *
     * @param libro El libro digital a registrar
     */
    public void registrarLibroDigital(LibroDigital libro) {
        bibliotecario.registrarLibroDigital(libro);
    }

    /**
     * Registra un nuevo libro de referencia en el sistema.
     *
     * @param libro El libro de referencia a registrar
     */
    public void registrarLibroReferencia(LibroReferencia libro) {
        bibliotecario.registrarLibroReferencia(libro);
    }

    /**
     * Obtiene la lista de todos los libros registrados.
     *
     * @return Lista de libros en el sistema
     */
    public List<Libro> obtenerLibros() {
        return bibliotecario.obtenerLibros();
    }

    /**
     * Registra un nuevo estudiante en el sistema.
     *
     * @param estudiante El estudiante a registrar
     */
    public void registrarEstudiante(Estudiante estudiante) {
        bibliotecario.registrarEstudiante(estudiante);
    }

    /**
     * Registra un nuevo docente en el sistema.
     *
     * @param docente El docente a registrar
     */
    public void registrarDocente(Docente docente) {
        bibliotecario.registrarDocente(docente);
    }

    /**
     * Registra un nuevo visitante en el sistema.
     *
     * @param visitante El visitante a registrar
     */
    public void registrarVisitante(Visitante visitante) {
        bibliotecario.registrarVisitante(visitante);
    }

    /**
     * Obtiene la lista de todos los usuarios registrados.
     *
     * @return Lista de usuarios en el sistema
     */
    public List<Persona> obtenerUsuarios() {
        return bibliotecario.obtenerUsuarios();
    }

    /**
     * Realiza el préstamo de un libro a un usuario.
     *
     * @param persona Usuario que solicita el préstamo
     * @param libro   Libro a prestar
     * @return true si el préstamo fue exitoso, false en caso contrario
     */
    public boolean prestarLibro(Persona persona, Libro libro) {
        return bibliotecario.prestarLibro(persona, libro);
    }

    /**
     * Registra la devolución de un libro.
     *
     * @param libro Libro a devolver
     * @return true si la devolución fue exitosa, false en caso contrario
     */
    public boolean devolverLibro(Libro libro) {
        return bibliotecario.devolverLibro(libro);
    }

    /**
     * Obtiene la lista de todos los préstamos registrados.
     *
     * @return Lista de préstamos en el sistema
     */
    public List<Prestamo> obtenerPrestamos() {
        return bibliotecario.obtenerPrestamos();
    }

    /**
     * Obtiene la lista de préstamos con devoluciones tardías.
     *
     * @return Lista de préstamos con devolución tardía
     */
    public List<Prestamo> obtenerDevolucionesTardias() {
        return bibliotecario.obtenerDevolucionesTardias();
    }

    /**
     * Muestra los préstamos actualmente activos en el sistema.
     */
    public void mostrarPrestamosActivos() {
        bibliotecario.mostrarPrestamosActivos();
    }

    /**
     * Busca y muestra un usuario por su ID.
     *
     * @param id ID del usuario a buscar
     * @return El usuario encontrado o null si no existe
     */
    public Persona mostrarUsuario(String id) {
        return bibliotecario.buscarUsuarioPorId(id);
    }

    /**
     * Obtiene la lista de libros más solicitados en préstamo.
     *
     * @return Lista de libros más solicitados
     */
    public List<Libro> obtenerLibroMasSolicitado() {
        return bibliotecario.obtenerLibroMasSolicitado();
    }

    /**
     * Busca un libro por su título.
     *
     * @param titulo Título del libro a buscar
     * @return El libro encontrado o null si no existe
     */
    public Libro buscarLibroPorTitulo(String titulo) {
        return bibliotecario.buscarLibroPorTitulo(titulo);
    }

    /**
     * Muestra todos los libros registrados en el sistema.
     */
    public void mostrarLibros() {
        bibliotecario.mostrarLibros();
    }
}