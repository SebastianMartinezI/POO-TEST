package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa un libro digital en el sistema de biblioteca.
 * Extiende de la clase Libro y agrega características específicas para libros en formato digital.
 */
public class LibroDigital extends Libro {
    private Formato formato;
    private String linkDescarga;

    /**
     * Constructor para crear un nuevo libro digital.
     *
     * @param titulo          El título del libro
     * @param autor           El autor del libro
     * @param genero          El género literario del libro
     * @param anioPublicacion El año de publicación del libro
     * @param estado          El estado actual del libro
     * @param formato         El formato digital del libro
     * @param linkDescarga    El enlace para descargar el libro
     */
    public LibroDigital(String titulo, String autor, String genero, int anioPublicacion, Estado estado,
                        Formato formato, String linkDescarga) {
        super(titulo, autor, genero, anioPublicacion, estado);
        this.formato = formato;
        this.linkDescarga = linkDescarga;
    }

    /**
     * Muestra toda la información relevante del libro digital en la consola.
     * Incluye título, autor, género, año, formato, link de descarga y estado.
     */
    public void mostrarInformacion() {
        System.out.println("Libro Digital:");
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Género: " + genero);
        System.out.println("Año: " + anioPublicacion);
        System.out.println("Formato: " + formato);
        System.out.println("Descargar: " + linkDescarga);
        System.out.println("Estado: " + estado);
        System.out.println();
    }

    /**
     * Obtiene el formato del libro digital.
     *
     * @return El formato del libro
     */
    public Formato getFormato() {
        return formato;
    }

    /**
     * Establece el formato del libro digital.
     *
     * @param formato El nuevo formato del libro
     */
    public void setFormato(Formato formato) {
        this.formato = formato;
    }

    /**
     * Obtiene el enlace de descarga del libro digital.
     *
     * @return El enlace de descarga
     */
    public String getLinkDescarga() {
        return linkDescarga;
    }

    /**
     * Establece el enlace de descarga del libro digital.
     *
     * @param linkDescarga El nuevo enlace de descarga
     */
    public void setLinkDescarga(String linkDescarga) {
        this.linkDescarga = linkDescarga;
    }
}
