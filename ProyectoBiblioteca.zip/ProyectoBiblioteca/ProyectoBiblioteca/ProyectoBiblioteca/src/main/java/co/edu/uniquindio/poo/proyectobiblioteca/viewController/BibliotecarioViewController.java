package co.edu.uniquindio.poo.proyectobiblioteca.viewController;
import co.edu.uniquindio.poo.proyectobiblioteca.controller.BibliotecarioController;
import co.edu.uniquindio.poo.proyectobiblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class BibliotecarioViewController implements Initializable {
    private BibliotecarioController controller;

    @FXML
    private TextField idField;
    @FXML
    private TextField nombreField;
    @FXML
    private TextField apellidoField;
    @FXML
    private TextField cedulaField;
    @FXML
    private TextField correoField;
    @FXML
    private TableView<Persona> usuariosTable;
    @FXML
    private TableColumn<Persona, String> idColumn;
    @FXML
    private TableColumn<Persona, String> nombreColumn;
    @FXML
    private TableColumn<Persona, String> apellidoColumn;
    @FXML
    private TableColumn<Persona, String> cedulaColumn;
    @FXML
    private TableColumn<Persona, String> correoColumn;
    @FXML
    private TableColumn<Persona, String> tipoColumn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Configurar las columnas de la tabla
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        apellidoColumn.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        cedulaColumn.setCellValueFactory(new PropertyValueFactory<>("cedula"));
        correoColumn.setCellValueFactory(new PropertyValueFactory<>("correo"));
        tipoColumn.setCellValueFactory(new PropertyValueFactory<>("tipo"));

        usuariosTable.setItems(FXCollections.observableArrayList());
        actualizarTabla();
    }

    @FXML
    private void registrarUsuario() {
        // Implementación del registro
    }

    @FXML
    private void buscarUsuario() {
        String id = idField.getText();
        Persona persona = controller.mostrarUsuario(id);
        if (persona != null) {
            nombreField.setText(persona.getNombre());
            apellidoField.setText(persona.getApellido());
            cedulaField.setText(persona.getCedula());
            correoField.setText(persona.getCorreo());
        }
    }

    @FXML
    private void modificarUsuario() {
        // Implementación de la modificación
    }

    @FXML
    private void eliminarUsuario() {
        // Implementación de la eliminación
    }

    @FXML
    private void limpiarCampos() {
        idField.clear();
        nombreField.clear();
        apellidoField.clear();
        cedulaField.clear();
        correoField.clear();
    }

    private void actualizarTabla() {
        if (controller != null) {
            ObservableList<Persona> usuarios = FXCollections.observableArrayList(controller.obtenerUsuarios());
            usuariosTable.setItems(usuarios);
        }
    }

    public void setController(BibliotecarioController controller) {
        this.controller = controller;
        actualizarTabla();
    }
}