package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa un empleado en el sistema de biblioteca.
 * Extiende de la clase Persona y añade funcionalidades específicas para empleados.
 */
public class Empleado extends Persona{
    public String usuario;
    public String contrasena;


    /**
     * Constructor para crear un nuevo empleado.
     *
     * @param nombre     El nombre del empleado
     * @param apellido   El apellido del empleado
     * @param cedula     La cédula del empleado
     * @param correo     El correo electrónico del empleado
     * @param usuario    El nombre de usuario para el sistema
     * @param contrasena La contraseña del empleado
     * @param id         El identificador único del empleado
     */
    public Empleado(String nombre, String apellido, String cedula, String correo, String usuario, String contrasena, String id) {
        super(nombre,apellido,cedula,correo,id);
        this.usuario = usuario;
        this.contrasena = contrasena;


    }

    /**
     * Establece el nombre de usuario del empleado.
     *
     * @param usuario El nuevo nombre de usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * Establece la contraseña del empleado.
     *
     * @param contrasena La nueva contraseña
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }


    /**
     * Obtiene el nombre de usuario del empleado.
     *
     * @return El nombre de usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * Obtiene la contraseña del empleado.
     *
     * @return La contraseña
     */
    public String getContrasena() {
        return contrasena;
    }

}
