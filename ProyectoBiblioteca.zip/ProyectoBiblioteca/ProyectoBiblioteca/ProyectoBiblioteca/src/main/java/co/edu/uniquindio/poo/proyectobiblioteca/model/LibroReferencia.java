package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa un libro de referencia en la biblioteca.
 * Los libros de referencia son aquellos que solo pueden ser consultados en sala
 * y no pueden ser prestados.
 */
public class LibroReferencia extends Libro {
    private String referencia;

    /**
     * Constructor para crear un nuevo libro de referencia.
     *
     * @param titulo          El título del libro
     * @param autor           El autor del libro
     * @param genero          El género del libro
     * @param anioPublicacion El año de publicación del libro
     * @param estado          El estado actual del libro
     * @param referencia      El código o número de referencia del libro
     */
    public LibroReferencia(String titulo, String autor, String genero, int anioPublicacion, Estado estado, String referencia) {
        super(titulo, autor, genero, anioPublicacion, estado);
        this.referencia = referencia;
    }

    /**
     * Muestra la información del libro de referencia.
     */
    public void mostrarInformacion() {
        System.out.println("Libro de Referencia (Solo consulta en sala):");
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Género: " + genero);
        System.out.println("Año: " + anioPublicacion);
        System.out.println("Estado: " + estado);
        System.out.println();
    }

    /**
     * Sobrescribe el metodo prestar para evitar que este tipo de libro sea prestado.
     */
    @Override
    public void prestar() {
        System.out.println("Este libro de referencia no puede ser prestado.");
    }

    /**
     * Obtiene el código o número de referencia del libro.
     *
     * @return El código de referencia del libro
     */
    public String getReferencia() {
        return referencia;
    }

    /**
     * Establece el código o número de referencia del libro.
     *
     * @param referencia El nuevo código de referencia para el libro
     */
    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }
}