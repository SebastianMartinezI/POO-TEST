package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa a un estudiante en el sistema de biblioteca.
 * Extiende de Persona e implementa la interfaz IDatosPrestamo para manejar
 * las reglas específicas de préstamos para estudiantes.
 */
public class Estudiante extends Persona implements IDatosPrestamo {


    /**
     * Constructor para crear un nuevo estudiante.
     *
     * @param nombre          El nombre del estudiante
     * @param apellido        El apellido del estudiante
     * @param cedula          La cédula del estudiante
     * @param correo          El correo electrónico del estudiante
     * @param id              El identificador único del estudiante
     */
    public Estudiante(String nombre, String apellido, String cedula, String correo,  String id) {
        super(nombre, apellido, cedula, correo,id);

    }


    /**
     * Obtiene el número de días permitidos para un préstamo de estudiante.
     *
     * @return El número de días permitidos para el préstamo (5 días)
     */
    @Override
    public int obtenerdiasprestamo() {
        return 5;
    }

    /**
     * Muestra la información completa del estudiante incluyendo
     * tipo de usuario, nombre, ID y límites de préstamo.
     */
    @Override
    public void mostrarInformacion() {
        System.out.println("Tipo de usuario: Estudiante");
        System.out.println("Nombre: " + getNombre());
        System.out.println("ID: " + getId());
        System.out.println("Días de préstamo permitidos: " + obtenerdiasprestamo());
        System.out.println("Límite de préstamos simultáneos: " + getLimitePrestamos());
        System.out.println("Límite de libros: " + getLimiteLibros());
    }

    /**
     * Obtiene el límite de préstamos simultáneos permitidos para un estudiante.
     *
     * @return El número máximo de préstamos simultáneos (2 préstamos)
     */
    @Override
    public int getLimitePrestamos() {
        return 2;
    }


    /**
     * Obtiene el límite de libros que puede tener prestados un estudiante.
     *
     * @return El número máximo de libros permitidos (3 libros)
     */
    public int getLimiteLibros() {
        return 3;
    }
}