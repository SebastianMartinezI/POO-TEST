package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Interface that defines the contract for loan-related operations in the library system.
 * Classes implementing this interface must provide functionality for managing loan durations,
 * displaying information, and handling loan limits based on user types.
 */
public interface IDatosPrestamo {
    /**
     * Determines the maximum number of days allowed for a loan.
     * Each user type can have different loan duration periods.
     *
     * @return The number of days allowed for the loan
     */
    public   int obtenerdiasprestamo();

    /**
     * Displays relevant information about the loan conditions and status.
     * Implementation should show user-specific loan details.
     */
    public void mostrarInformacion();

    /**
     * Defines the maximum number of simultaneous loans allowed for a user type.
     * Different user categories may have different loan limits.
     *
     * @return The maximum number of loans allowed
     */
    public  int getLimitePrestamos();

}
