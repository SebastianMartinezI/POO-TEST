package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Enumeración que representa los posibles estados de un recurso en la biblioteca.
 * Define los estados que puede tener un libro u otro material bibliográfico.
 */
public enum Estado {
    /**
     * Indica que el recurso está disponible para ser prestado
     */
    DISPONIBLE,
    /**
     * Indica que el recurso está actualmente prestado a un usuario
     */
    PRESTADO
}
