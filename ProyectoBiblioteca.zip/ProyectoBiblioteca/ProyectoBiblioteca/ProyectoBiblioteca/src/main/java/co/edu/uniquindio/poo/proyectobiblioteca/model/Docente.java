package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa a un Docente en el sistema de biblioteca.
 * Extiende de Persona e implementa la interfaz IDatosPrestamo para definir
 * las reglas específicas de préstamo para docentes.
 */
public class Docente extends Persona implements IDatosPrestamo {


    /**
     * Constructor para crear un nuevo docente.
     *
     * @param nombre          El nombre del docente
     * @param apellido        El apellido del docente
     * @param cedula          La cédula del docente
     * @param correo          El correo electrónico del docente
     * @param limitePrestamos El límite de préstamos permitidos
     * @param id              El identificador único del docente
     */
    public Docente(String nombre, String apellido, String cedula, String correo,  int limitePrestamos, String id) {
        super(nombre, apellido, cedula, correo,id);

    }

    /**
     * Obtiene la cantidad de días máximos para un préstamo de un docente.
     *
     * @return El número de días permitidos para el préstamo (10 días)
     */
    @Override
    public int obtenerdiasprestamo() {
        int diasPrestamo = 10;
        return diasPrestamo;
    }

    /**
     * Muestra la información completa del docente incluyendo nombre,
     * apellido, cédula, correo, límite de préstamos y días de préstamo permitidos.
     */
    @Override
    public void mostrarInformacion() {
        System.out.println("=== Información del Docente ===");
        System.out.println("Nombre: " + getNombre());
        System.out.println("Apellido: " + getApellido());
        System.out.println("Cédula: " + getCedula());
        System.out.println("Correo: " + getCorreo());
        System.out.println("ID: " + getId());
        System.out.println("Límite de préstamos: " + getLimitePrestamos());
        System.out.println("Días de préstamo: " + obtenerdiasprestamo());
        System.out.println("==============================");
    }

    /**
     * Obtiene el límite máximo de préstamos simultáneos permitidos para un docente.
     *
     * @return El número máximo de préstamos permitidos (5 préstamos)
     */
    @Override
    public int getLimitePrestamos() {
        return 6;
    }

    /**
     * Obtiene el límite máximo de libros que puede tener prestados un docente.
     *
     * @return El número máximo de libros permitidos (5 libros)
     */
    public int getLimiteLibros(){
        return 6 ;
    }


}