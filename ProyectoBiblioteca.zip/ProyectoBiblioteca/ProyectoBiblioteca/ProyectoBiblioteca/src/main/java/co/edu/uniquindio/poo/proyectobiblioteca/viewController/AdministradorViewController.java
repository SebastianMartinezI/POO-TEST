package co.edu.uniquindio.poo.proyectobiblioteca.viewController;

import co.edu.uniquindio.poo.proyectobiblioteca.controller.AdministradorController;
import co.edu.uniquindio.poo.proyectobiblioteca.model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class AdministradorViewController {
    @FXML
    private TextField idField;
    @FXML
    private TextField nombreField;
    @FXML
    private TextField apellidoField;
    @FXML
    private TextField cedulaField;
    @FXML
    private TextField correoField;

    @FXML
    private TableView<Persona> usuariosTable;
    @FXML
    private TableColumn<Persona, String> idColumn;
    @FXML
    private TableColumn<Persona, String> nombreColumn;
    @FXML
    private TableColumn<Persona, String> apellidoColumn;
    @FXML
    private TableColumn<Persona, String> cedulaColumn;
    @FXML
    private TableColumn<Persona, String> correoColumn;
    @FXML
    private TableColumn<Persona, String> tipoColumn;

    private AdministradorController controller;
    private ObservableList<Persona> usuariosData;

    @FXML
    public void initialize() {
        usuariosData = FXCollections.observableArrayList();
        usuariosTable.setItems(usuariosData);

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        apellidoColumn.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        cedulaColumn.setCellValueFactory(new PropertyValueFactory<>("cedula"));
        correoColumn.setCellValueFactory(new PropertyValueFactory<>("correo"));
        tipoColumn.setCellValueFactory(new PropertyValueFactory<>("tipo"));
    }

    public void setController(AdministradorController controller) {
        this.controller = controller;
        actualizarTabla();
    }

    Empleado empleado = new Empleado(
            nombreField.getText(),
            apellidoField.getText(),
            cedulaField.getText(),
            correoField.getText(),
            "", //usuario
            "", //contraseña
            idField.getText()
    );

    @FXML
    private void buscarUsuario() {
        String id = idField.getText();
        if (id != null && !id.isEmpty()) {
            Persona usuario = controller.buscarUsuarioPorId(id);
            if (usuario != null) {
                nombreField.setText(usuario.getNombre());
                apellidoField.setText(usuario.getApellido());
                cedulaField.setText(usuario.getCedula());
                correoField.setText(usuario.getCorreo());
            } else {
                mostrarAlerta("Búsqueda", "Usuario no encontrado");
            }
        }
    }

    @FXML
    private void modificarUsuario() {
        try {
            if (idField.getText().isEmpty() || nombreField.getText().isEmpty() ||
                    apellidoField.getText().isEmpty() || cedulaField.getText().isEmpty() ||
                    correoField.getText().isEmpty()) {
                mostrarAlerta("Error", "Todos los campos son obligatorios");
                return;
            }

            Empleado empleado = new Empleado(
                    nombreField.getText(),
                    apellidoField.getText(),
                    cedulaField.getText(),
                    correoField.getText(),
                    "", //usuario
                    "", //contraseña
                    idField.getText()
            );
            controller.modificarEmpleado(empleado);
            actualizarTabla();
            limpiarCampos();
            mostrarAlerta("Éxito", "Usuario modificado correctamente");
        } catch (Exception e) {
            mostrarAlerta("Error al modificar", e.getMessage());
        }
    }

    @FXML
    private void eliminarUsuario() {
        try {
            if (idField.getText().isEmpty()) {
                mostrarAlerta("Error", "Debe seleccionar un usuario para eliminar");
                return;
            }

            Empleado empleado = new Empleado(
                    nombreField.getText(),
                    apellidoField.getText(),
                    cedulaField.getText(),
                    correoField.getText(),
                    "", //usuario
                    "", //contraseña
                    idField.getText()
            );
            controller.eliminarEmpleado(empleado);
            actualizarTabla();
            limpiarCampos();
            mostrarAlerta("Éxito", "Usuario eliminado correctamente");
        } catch (Exception e) {
            mostrarAlerta("Error al eliminar", e.getMessage());
        }
    }

    @FXML
    private void limpiarCampos() {
        idField.clear();
        nombreField.clear();
        apellidoField.clear();
        cedulaField.clear();
        correoField.clear();
    }

    private void actualizarTabla() {
        usuariosData.clear();
        usuariosData.addAll(controller.obtenerUsuarios());
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void autenticarEmpleado() {
        // Implementación pendiente
    }
}