package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Enumeración que representa los diferentes formatos disponibles para los libros digitales
 * en el sistema de biblioteca.
 */
public enum Formato {
    /**
     * Formato PDF (Portable Document Format).
     * Formato estándar para documentos digitales.
     */
    PDF,

    /**
     * Formato EPUB (Electronic Publication).
     * Formato estándar para libros electrónicos.
     */
    EPUB,

    /**
     * Formato MOBI (Mobipocket).
     * Formato propietario de Amazon para libros electrónicos Kindle.
     */
    MOBI
}
