package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa a un Visitante en el sistema de biblioteca.
 * Extiende de Persona e implementa la interfaz IDatosPrestamo para definir
 * las reglas específicas de préstamo para visitantes.
 */
public class Visitante extends Persona implements IDatosPrestamo {


    /**
     * Constructor para crear un nuevo visitante.
     *
     * @param nombre   El nombre del visitante
     * @param apellido El apellido del visitante
     * @param cedula   La cédula del visitante
     * @param correo   El correo electrónico del visitante
     * @param id       El identificador único del visitante
     */
    public Visitante(String nombre, String apellido, String cedula, String correo,String id) {
        super(nombre, apellido, cedula, correo,id);

    }

    /**
     * Obtiene la cantidad de días máximos para un préstamo de un visitante.
     *
     * @return El número de días permitidos para el préstamo (0 días)
     */
    @Override
    public int obtenerdiasprestamo() {
        return 0;
    }

    /**
     * Muestra la información completa del visitante incluyendo nombre,
     * apellido, cédula, correo, límite de préstamos y días de préstamo permitidos.
     */
    @Override
    public void mostrarInformacion() {
        System.out.println("=== Información del Visitante ===");
        System.out.println("Nombre: " + getNombre());
        System.out.println("Apellido: " + getApellido());
        System.out.println("Cédula: " + getCedula());
        System.out.println("Correo: " + getCorreo());
        System.out.println("ID: " + getId());
        System.out.println("Límite de préstamos: " + getLimitePrestamos());
        System.out.println("Días de préstamo: " + obtenerdiasprestamo());
        System.out.println("==============================");
    }

    /**
     * Obtiene el límite máximo de préstamos simultáneos permitidos para un visitante.
     *
     * @return El número máximo de préstamos permitidos (0 préstamos)
     */
    @Override
    public int getLimitePrestamos() {
        return 0;
    }

    /**
     * Obtiene el límite máximo de libros que puede tener prestados un visitante.
     *
     * @return El número máximo de libros permitidos (0 libros)
     */
    public int getLimiteLibros(){
        return 0;
    }


}
