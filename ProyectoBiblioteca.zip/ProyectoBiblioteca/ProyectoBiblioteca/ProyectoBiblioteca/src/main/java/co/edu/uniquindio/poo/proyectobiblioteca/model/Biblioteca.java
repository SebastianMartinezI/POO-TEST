package co.edu.uniquindio.poo.proyectobiblioteca.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa una biblioteca y gestiona su funcionamiento.
 * Mantiene registros de diferentes tipos de libros y usuarios del sistema.
 */
public class Biblioteca {
    /**
     * Nombre de la biblioteca
     */
    public String nombre;
    /**
     * Ubicación física de la biblioteca
     */
    public String ubicacion;
    /**
     * Lista de todos los libros en la biblioteca
     */
    public List<Libro> listLibro;
    /**
     * Lista de libros físicos disponibles
     */
    public List<LibroFisico> listLibroFisico;
    /**
     * Lista de libros digitales disponibles
     */
    public List<LibroDigital> listLibroDigital;
    /**
     * Lista de libros de referencia
     */
    public List<LibroReferencia> ListlibroReferencia;
    /**
     * Lista de todas las personas registradas
     */
    public List<Persona> listpersona;
    /**
     * Lista de empleados de la biblioteca
     */
    public List<Empleado> listEmpleado;
    /**
     * Lista de estudiantes registrados
     */
    public List<Estudiante> listEstudiante;
    /**
     * Lista de docentes registrados
     */
    public List<Docente> listDocente;
    /**
     * Lista de visitantes registrados
     */
    public List<Visitante> listVisitante;
    /**
     * Lista de administradores del sistema
     */
    public List<Administrador> listAdministrador;
    /**
     * Lista de bibliotecarios
     */
    public List<Bibliotecario> listBibliotecario;

    /**
     * Constructor de la clase Biblioteca
     *
     * @param nombre    Nombre de la biblioteca
     * @param ubicacion Ubicación física de la biblioteca
     */
    public Biblioteca(String nombre, String ubicacion) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.listLibro = new ArrayList<>();
        this.listLibroFisico = new ArrayList<>();
        this.listLibroDigital = new ArrayList<>();
        this.ListlibroReferencia = new ArrayList<>();
        this.listpersona = new ArrayList<>();
        this.listEmpleado = new ArrayList<>();
        this.listEstudiante = new ArrayList<>();
        this.listDocente = new ArrayList<>();
        this.listVisitante = new ArrayList<>();
        this.listAdministrador = new ArrayList<>();
        this.listBibliotecario = new ArrayList<>();
    }

    /**
     * Registra un nuevo libro en la biblioteca
     *
     * @param libro Libro a registrar
     */
    public void registrarLibro(Libro libro) {
        listLibro.add(libro);
    }

    /**
     * Registra un nuevo libro físico en la biblioteca
     *
     * @param libroFisico Libro físico a registrar
     */
    public void registrarLibroFisico(LibroFisico libroFisico) {
        listLibroFisico.add(libroFisico);
    }

    /**
     * Registra un nuevo libro digital en la biblioteca
     *
     * @param libroDigital Libro digital a registrar
     */
    public void registrarLibroDigital(LibroDigital libroDigital) {
        listLibroDigital.add(libroDigital);
    }

    /**
     * Registra un nuevo libro de referencia en la biblioteca
     *
     * @param libroReferencia Libro de referencia a registrar
     */
    public void registrarLibroReferencia(LibroReferencia libroReferencia) {
        ListlibroReferencia.add(libroReferencia);
    }

    /**
     * Registra una nueva persona en la biblioteca
     *
     * @param persona Persona a registrar
     */
    public void registrarPersona(Persona persona) {
        listpersona.add(persona);
    }

    /**
     * Registra un nuevo empleado en la biblioteca
     *
     * @param empleado Empleado a registrar
     */
    public void registrarEmpleado(Empleado empleado) {
        listEmpleado.add(empleado);
    }

    /**
     * Registra un nuevo estudiante en la biblioteca
     *
     * @param estudiante Estudiante a registrar
     */
    public void registrarEstudiante(Estudiante estudiante) {
        listEstudiante.add(estudiante);
    }

    /**
     * Registra un nuevo docente en la biblioteca
     *
     * @param docente Docente a registrar
     */
    public void registrarDocente(Docente docente) {
        listDocente.add(docente);
    }

    /**
     * Registra un nuevo visitante en la biblioteca
     *
     * @param visitante Visitante a registrar
     */
    public void registrarVisitante(Visitante visitante) {
        listVisitante.add(visitante);
    }

    /**
     * Registra un nuevo administrador en la biblioteca
     *
     * @param administrador Administrador a registrar
     */
    public void registrarAdministrador(Administrador administrador) {
        listAdministrador.add(administrador);
    }

    /**
     * Registra un nuevo bibliotecario en la biblioteca
     *
     * @param bibliotecario Bibliotecario a registrar
     */
    public void registrarBibliotecario(Bibliotecario bibliotecario) {
        listBibliotecario.add(bibliotecario);
    }

    /**
     * Obtiene el nombre de la biblioteca
     *
     * @return nombre de la biblioteca
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre de la biblioteca
     *
     * @param nombre nuevo nombre de la biblioteca
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la ubicación de la biblioteca
     *
     * @return ubicación de la biblioteca
     */
    public String getUbicacion() {
        return ubicacion;
    }

    /**
     * Establece la ubicación de la biblioteca
     *
     * @param ubicacion nueva ubicación de la biblioteca
     */
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    /**
     * Obtiene la lista de libros físicos
     *
     * @return lista de libros físicos
     */
    public List<LibroFisico> getListLibroFisico() {
        return listLibroFisico;
    }

    /**
     * Establece la lista de libros físicos
     *
     * @param listLibroFisico nueva lista de libros físicos
     */
    public void setListLibroFisico(List<LibroFisico> listLibroFisico) {
        this.listLibroFisico = listLibroFisico;
    }

    /**
     * Obtiene la lista general de libros
     *
     * @return lista de todos los libros
     */
    public List<Libro> getListLibro() {
        return listLibro;
    }

    /**
     * Establece la lista general de libros
     *
     * @param listLibro nueva lista de libros
     */
    public void setListLibro(List<Libro> listLibro) {
        this.listLibro = listLibro;
    }

    /**
     * Obtiene la lista de libros digitales
     *
     * @return lista de libros digitales
     */
    public List<LibroDigital> getListLibroDigital() {
        return listLibroDigital;
    }

    /**
     * Establece la lista de libros digitales
     *
     * @param listLibroDigital nueva lista de libros digitales
     */
    public void setListLibroDigital(List<LibroDigital> listLibroDigital) {
        this.listLibroDigital = listLibroDigital;
    }

    /**
     * Obtiene la lista de personas registradas
     *
     * @return lista de personas
     */
    public List<Persona> getListpersona() {
        return listpersona;
    }

    /**
     * Establece la lista de personas registradas
     *
     * @param listpersona nueva lista de personas
     */
    public void setListpersona(List<Persona> listpersona) {
        this.listpersona = listpersona;
    }

    /**
     * Obtiene la lista de libros de referencia
     *
     * @return lista de libros de referencia
     */
    public List<LibroReferencia> getListlibroReferencia() {
        return ListlibroReferencia;
    }

    /**
     * Establece la lista de libros de referencia
     *
     * @param listlibroReferencia nueva lista de libros de referencia
     */
    public void setListlibroReferencia(List<LibroReferencia> listlibroReferencia) {
        ListlibroReferencia = listlibroReferencia;
    }

    /**
     * Obtiene la lista de empleados
     *
     * @return lista de empleados
     */
    public List<Empleado> getListEmpleado() {
        return listEmpleado;
    }

    /**
     * Establece la lista de empleados
     *
     * @param listEmpleado nueva lista de empleados
     */
    public void setListEmpleado(List<Empleado> listEmpleado) {
        this.listEmpleado = listEmpleado;
    }

    /**
     * Obtiene la lista de estudiantes
     *
     * @return lista de estudiantes
     */
    public List<Estudiante> getListEstudiante() {
        return listEstudiante;
    }

    /**
     * Establece la lista de estudiantes
     *
     * @param listEstudiante nueva lista de estudiantes
     */
    public void setListEstudiante(List<Estudiante> listEstudiante) {
        this.listEstudiante = listEstudiante;
    }

    /**
     * Obtiene la lista de docentes
     *
     * @return lista de docentes
     */
    public List<Docente> getListDocente() {
        return listDocente;
    }

    /**
     * Establece la lista de docentes
     *
     * @param listDocente nueva lista de docentes
     */
    public void setListDocente(List<Docente> listDocente) {
        this.listDocente = listDocente;
    }

    /**
     * Obtiene la lista de visitantes
     *
     * @return lista de visitantes
     */
    public List<Visitante> getListVisitante() {
        return listVisitante;
    }

    /**
     * Establece la lista de visitantes
     *
     * @param listVisitante nueva lista de visitantes
     */
    public void setListVisitante(List<Visitante> listVisitante) {
        this.listVisitante = listVisitante;
    }

    /**
     * Obtiene la lista de administradores
     *
     * @return lista de administradores
     */
    public List<Administrador> getListAdministrador() {
        return listAdministrador;
    }

    /**
     * Establece la lista de administradores
     *
     * @param listAdministrador nueva lista de administradores
     */
    public void setListAdministrador(List<Administrador> listAdministrador) {
        this.listAdministrador = listAdministrador;
    }

    /**
     * Obtiene la lista de bibliotecarios
     *
     * @return lista de bibliotecarios
     */
    public List<Bibliotecario> getListBibliotecario() {
        return listBibliotecario;
    }

    /**
     * Establece la lista de bibliotecarios
     *
     * @param listBibliotecario nueva lista de bibliotecarios
     */
    public void setListBibliotecario(List<Bibliotecario> listBibliotecario) {
        this.listBibliotecario = listBibliotecario;
    }
}