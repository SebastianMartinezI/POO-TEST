package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa una persona en el sistema de biblioteca.
 * Contiene la información básica común para todos los tipos de usuarios.
 */
public class Persona {
    private String nombre;
    private String apellido;
    private String cedula;
    private String correo;
    private String id;



    /**
     * Constructor para crear una nueva persona.
     *
     * @param nombre   El nombre de la persona
     * @param apellido El apellido de la persona
     * @param cedula   La cédula de la persona
     * @param correo   El correo electrónico de la persona
     * @param id       El identificador único de la persona
     */
    public Persona(String nombre, String apellido, String cedula, String correo, String id) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.correo = correo;
        this.id=id;
    }
    /**
     * Obtiene el identificador único de la persona.
     *
     * @return El ID de la persona
     */
    public String getId() {
        return id;
    }

    /**
     * Establece el identificador único de la persona.
     *
     * @param id El nuevo ID de la persona
     */
    public void setId(String id) {
        this.id = id;
    }


    /**
     * Obtiene el nombre de la persona.
     *
     * @return El nombre de la persona
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre de la persona.
     *
     * @param nombre El nuevo nombre de la persona
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el apellido de la persona.
     *
     * @return El apellido de la persona
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * Establece el apellido de la persona.
     *
     * @param apellido El nuevo apellido de la persona
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * Obtiene la cédula de la persona.
     *
     * @return La cédula de la persona
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * Establece la cédula de la persona.
     *
     * @param cedula La nueva cédula de la persona
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * Obtiene el correo electrónico de la persona.
     *
     * @return El correo electrónico de la persona
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Establece el correo electrónico de la persona.
     *
     * @param correo El nuevo correo electrónico de la persona
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Devuelve una representación en cadena de la persona.
     *
     * @return Una cadena que contiene todos los atributos de la persona
     */
    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", cedula='" + cedula + '\'' +
                ", correo='" + correo + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}