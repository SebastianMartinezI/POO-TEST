package co.edu.uniquindio.poo.proyectobiblioteca.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa un Administrador en el sistema de biblioteca.
 * El administrador tiene la capacidad de gestionar empleados y usuarios del sistema,
 * incluyendo el registro, modificación y eliminación de los mismos.
 */
public class Administrador extends Empleado {
    /**
     * Lista general de todas las personas registradas en el sistema
     */
    public List<Persona> listPersonas;
    /**
     * Lista específica de empleados de la biblioteca
     */
    public List<Empleado> empleados;
    /**
     * Lista de usuarios (estudiantes, docentes y visitantes)
     */
    public List<Persona> ListUsuarios;


    public void mostrarRol() {
        System.out.println("Rol: Administrador");
    }
    /**
     * Constructor para crear un nuevo administrador.
     *
     * @param nombre   El nombre del administrador
     * @param apellido El apellido del administrador
     * @param cedula   La cédula del administrador
     * @param correo   El correo electrónico del administrador
     * @param id       El identificador único del administrador
     */
    public Administrador(String nombre, String apellido, String cedula, String correo,String id, String usuario, String contrasenia) {
        super(nombre,apellido,cedula,correo,id,usuario, contrasenia);
        this.listPersonas = new ArrayList<>();
        this.empleados = new ArrayList<>();
        this.ListUsuarios=new ArrayList<>();
    }

    /**
     * Registra un nuevo empleado en el sistema.
     * Verifica si el empleado ya existe antes de agregarlo.
     *
     * @param empleado El empleado a registrar en el sistema
     */
    public void registrarEmpleado(Empleado empleado) {
        if (buscarEmpleado(empleado) != null) {
            System.out.println("Ya existe un empleado con ese usuario.");
        }

        empleados.add(empleado);
        System.out.println("Empleado registrado correctamente.");
    }

    /**
     * Elimina un empleado del sistema.
     * Busca al empleado por su nombre de usuario y lo remueve de la lista.
     *
     * @param empleado El empleado a eliminar del sistema
     */
    public void eliminarEmpleado(Empleado empleado) {
        for (int i = 0; i < empleados.size(); i++) {
            if (empleados.get(i).getUsuario().equals(empleado.getUsuario())) {
                empleados.remove(i);
                System.out.println("Empleado eliminado: " + empleado.getUsuario());
                return;
            }
        }
        System.out.println("Empleado no encontrado.");
    }

    /**
     * Busca un empleado en el sistema por su nombre de usuario.
     *
     * @param empleado El empleado a buscar
     * @return El empleado encontrado o null si no existe
     */
    public Empleado buscarEmpleado(Empleado empleado) {
        for (Empleado emp : empleados) {
            if (emp.getUsuario().equals(empleado.getUsuario())) {
                return emp;
            }
        }
        return null;
    }

    /**


     /**
     * Muestra todos los empleados registrados con su rol.
     */
    public void mostrarEmpleados() {
        for (Empleado empleado : empleados) {
            System.out.println("Usuario: " + empleado.getUsuario() + " | Nombre: " + empleado.getNombre());

        }
    }

    /**
     * Modifica la información de un empleado existente.
     * Actualiza los datos del empleado si se encuentra en el sistema.
     *
     * @param empleado El empleado con la información actualizada
     */
    public void modificarEmpleado(Empleado empleado) {
        for (int i = 0; i <= empleados.size(); i++) {
            if (empleados.get(i).getUsuario().equals(empleado.getUsuario())) {
                empleados.set(i, empleado);
            }
        }
    }


    /**
     * Devuelve la lista de empleados
     */
    public List<Empleado> obtenerEmpleados() {
        return empleados;
    }

    /**
     * Registra un estudiante en el sistema.
     */
    public void registrarEstudiante(Estudiante estudiante) {
        if (buscarUsuarioPorId(estudiante.getId()) != null) {
            System.out.println("Ya existe un usuario con ese ID.");
            return;
        }

        ListUsuarios.add(estudiante);
        System.out.println("Estudiante registrado.");
    }

    /**
     * Registra un docente en el sistema.
     */
    public void registrarDocente(Docente docente) {
        if (buscarUsuarioPorId(docente.getId()) != null) {
            System.out.println("Ya existe un usuario con ese ID.");
            return;
        }

        ListUsuarios.add(docente);
        System.out.println("Docente registrado.");
    }

    /**
     * Registra un visitante en el sistema.
     */
    public void registrarVisitante(Visitante visitante) {
        if (buscarUsuarioPorId(visitante.getId()) != null) {
            System.out.println("Ya existe un usuario con ese ID.");
            return;
        }
        ListUsuarios.add(visitante);
        System.out.println("Visitante registrado.");
    }

    /**
     * Busca un usuario por su ID.
     */
    public Persona buscarUsuarioPorId(String id) {
        for (Persona usuario : ListUsuarios) {
            if (usuario.getId().equalsIgnoreCase(id)) {
                return usuario;
            }
        }
        return null;
    }

    /**
     * Muestra en consola todos los usuarios registrados.
     */
    public void mostrarUsuarios() {
        if (ListUsuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }
        for (Persona usuario : ListUsuarios) {
            System.out.println("Usuario: " + usuario.getNombre() + " | ID: " + usuario.getId());
        }
    }

    /**
     * Devuelve la lista completa de usuarios registrados.
     */
    public List<Persona> obtenerUsuarios() {
        return ListUsuarios;
    }
}

