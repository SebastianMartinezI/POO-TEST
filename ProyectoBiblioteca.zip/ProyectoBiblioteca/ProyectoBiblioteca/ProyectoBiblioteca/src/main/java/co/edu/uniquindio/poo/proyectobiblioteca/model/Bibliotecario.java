package co.edu.uniquindio.poo.proyectobiblioteca.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa un Bibliotecario en el sistema de biblioteca.
 * El bibliotecario es responsable de gestionar préstamos, libros y usuarios.
 * Puede registrar diferentes tipos de libros, gestionar préstamos y usuarios,
 * y llevar un control de las devoluciones.
 */
public class Bibliotecario extends Persona {
    private List<Persona> listUsuarios2;
    private List<Prestamo> listPrestamos;
    private List<Libro> libros;

    /**
     * Constructor para crear un nuevo bibliotecario.
     *
     * @param nombre   El nombre del bibliotecario
     * @param apellido El apellido del bibliotecario
     * @param cedula   La cédula del bibliotecario
     */
    public Bibliotecario(String nombre, String apellido, String cedula, String correo,String id) {
        super(nombre,apellido,cedula,correo,id);
        this.listUsuarios2=new ArrayList<>();
        this.listPrestamos=new ArrayList<>();
    }
    /**
     * Registra un nuevo libro físico en el sistema.
     */
    public void registrarLibroFisico(LibroFisico libro) {
        libros.add(libro);
        System.out.println("Libro físico registrado.");
    }

    /**
     * Registra un libro digital.
     */
    public void registrarLibroDigital(LibroDigital libro) {
        libros.add(libro);
        System.out.println("Libro digital registrado.");
    }

    /**
     * Registra un libro de referencia (solo consulta).
     */
    public void registrarLibroReferencia(LibroReferencia libro) {
        libros.add(libro);
        System.out.println("Libro de referencia registrado.");
    }

    /**
     * Muestra en consola todos los libros registrados.
     */
    public void mostrarLibros() {
        for (Libro libro : libros) {
            libro.mostrarInformacion();
        }
    }

    /**
     * Busca un libro por título.
     */
    public Libro buscarLibroPorTitulo(String titulo) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                return libro;
            }
        }
        return null;
    }

    /**
     * Devuelve la lista de libros registrados.
     */
    public List<Libro> obtenerLibros() {
        return libros;
    }

    /**
     * Registra el préstamo de un libro a un usuario.
     * Verifica la disponibilidad del libro y los límites de préstamo del usuario.
     *
     * @param persona El usuario que solicita el préstamo
     * @param libro   El libro a prestar
     * @return true si el préstamo fue exitoso, false en caso contrario
     */
    public boolean prestarLibro(Persona persona, Libro libro) {
        if (libro == null || persona == null) {
            return false;
        }

        if (!libro.estaDisponible()) {
            System.out.println("El libro no está disponible.");
            return false;
        }

        int prestamosUsuario = contarPrestamosActivos(persona);
        if (prestamosUsuario >= ((IDatosPrestamo) persona).getLimitePrestamos()) {
            System.out.println("El usuario ha alcanzado su límite de préstamos.");
            return false;
        }

        Prestamo prestamo = new Prestamo(persona, libro);
        listPrestamos.add(prestamo);
        libro.prestar();
        System.out.println("Préstamo registrado con éxito.");
        return true;
    }

    /**
     * Registra la devolución de un libro.
     */
    public boolean devolverLibro(Libro libro) {
        for (Prestamo prestamo : listPrestamos) {
            if (prestamo.getLibro().equals(libro)) {
                libro.devolver();
                listPrestamos.remove(prestamo);
                System.out.println("Libro devuelto con éxito.");
                return true;
            }
        }
        System.out.println("El libro no estaba prestado.");
        return false;
    }
    /**
     * Devuelve una lista de los préstamos que fueron devueltos después de la fecha límite.
     */
    public List<Prestamo> obtenerDevolucionesTardias() {
        List<Prestamo> devolucionesTardias = new ArrayList<>();


        for (Prestamo prestamo : listPrestamos) {
            LocalDate fechaPrestamo = prestamo.getFechaPrestamo();
            LocalDate fechaDevolucion = prestamo.getFechaDevolucion();

            int anioPrestamo = fechaPrestamo.getYear();
            int mesPrestamo = fechaPrestamo.getMonthValue();
            int diaPrestamo = fechaPrestamo.getDayOfMonth();

            int anioDevuelto = fechaDevolucion.getYear();
            int mesDevuelto = fechaDevolucion.getMonthValue();
            int diaDevuelto = fechaDevolucion.getDayOfMonth();
            if(diaPrestamo<diaDevuelto){
                devolucionesTardias.add(prestamo);
            }
        }
        return devolucionesTardias;
    }

    /**
     * Obtiene una lista de los libros más solicitados en préstamo.
     *
     * @return Lista de libros que han sido prestados con mayor frecuencia
     */
    public List<Libro> obtenerLibroMasSolicitado() {
        List<Libro> librosMasSolicitados = new ArrayList<>();
        int maximoPrestamos = 0;

        for (Prestamo prestamo : listPrestamos) {
            Libro libro = prestamo.getLibro();
            int cantidadPrestamos = contarPrestamosPorLibro(libro);

            if (cantidadPrestamos > maximoPrestamos) {
                maximoPrestamos = cantidadPrestamos;
                librosMasSolicitados.add(libro);
            } else if (cantidadPrestamos == maximoPrestamos ) {
                librosMasSolicitados.add(libro);
            }
        }
        return librosMasSolicitados;
    }

    /**
     * Cuenta el número de veces que un libro específico ha sido prestado.
     *
     * @param libro El libro del cual se quiere contar los préstamos
     * @return Número de veces que el libro ha sido prestado
     */
    private int contarPrestamosPorLibro(Libro libro) {
        int contador = 0;
        for (Prestamo prestamo : listPrestamos) {
            if (prestamo.getLibro().equals(libro)) {
                contador++;
            }
        }
        return contador;
    }


    /**
     * Cuenta cuántos préstamos activos tiene un usuario.
     */
    public int contarPrestamosActivos(Persona usuario) {
        int contador = 0;
        for (Prestamo prestamo : listPrestamos) {
            if (prestamo.getUsuario().equals(usuario)) {
                contador++;
            }
        }
        return contador;
    }

    /**
     * Muestra en consola todos los préstamos activos.
     */
    public void mostrarPrestamosActivos() {
        for (Prestamo prestamo : listPrestamos) {
            System.out.println("Libro: " + prestamo.getLibro().getTitulo() + " | Usuario: " + prestamo.getUsuario().getNombre() +
                    " | Fecha devolución: " + prestamo.getFechaDevolucion());
        }
    }

    /**
     * Devuelve la lista completa de préstamos activos.
     */
    public List<Prestamo> obtenerPrestamos() {
        return listPrestamos;
    }
    /**
     * Registra un estudiante en el sistema.
     */
    public void registrarEstudiante(Estudiante estudiante) {
        if (buscarUsuarioPorId(estudiante.getId()) != null) {
            System.out.println("Ya existe un usuario con ese ID.");
            return;
        }

        listUsuarios2.add(estudiante);
        System.out.println("Estudiante registrado.");
    }

    /**
     * Registra un docente en el sistema.
     */
    public void registrarDocente(Docente docente) {
        if (buscarUsuarioPorId(docente.getId()) != null) {
            System.out.println("Ya existe un usuario con ese ID.");
            return;
        }

        listUsuarios2.add(docente);
        System.out.println("Docente registrado.");
    }

    /**
     * Registra un visitante en el sistema.
     */
    public void registrarVisitante(Visitante visitante) {
        if (buscarUsuarioPorId(visitante.getId()) != null) {
            System.out.println("Ya existe un usuario con ese ID.");
            return;
        }
        listUsuarios2.add(visitante);
        System.out.println("Visitante registrado.");
    }

    /**
     * Busca un usuario por su ID.
     */
    public Persona buscarUsuarioPorId(String id) {
        for (Persona usuario : listUsuarios2) {
            if (usuario.getCedula().equalsIgnoreCase(id)) {
                return usuario;
            }
        }
        return null;
    }

    /**
     * Muestra en consola todos los usuarios registrados.
     */
    public void mostrarUsuarios() {
        if (listUsuarios2.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }
        for (Persona usuario : listUsuarios2) {
            ((IDatosPrestamo) usuario).mostrarInformacion();
        }
    }
    /**
     * Devuelve la lista completa de usuarios registrados.
     */
    public List<Persona> obtenerUsuarios() {
        return listUsuarios2;
    }
}
