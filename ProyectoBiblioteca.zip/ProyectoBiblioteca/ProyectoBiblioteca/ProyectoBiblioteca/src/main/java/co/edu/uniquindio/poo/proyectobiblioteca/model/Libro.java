package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase abstracta que representa un libro en el sistema de biblioteca.
 * Contiene la información básica común para todos los tipos de libros.
 */
public abstract class Libro {
    protected String titulo;
    protected String autor;
    protected String genero;
    protected int anioPublicacion;
    protected Estado estado;

    /**
     * Constructor para crear un nuevo libro.
     *
     * @param titulo          El título del libro
     * @param autor           El autor del libro
     * @param genero          El género literario del libro
     * @param anioPublicacion El año de publicación del libro
     * @param estado          El estado inicial del libro
     */
    public Libro(String titulo, String autor, String genero, int anioPublicacion, Estado estado) {
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.anioPublicacion = anioPublicacion;
        this.estado = Estado.DISPONIBLE;
    }
    // Clase abstracta que permitira a los libros de diferente tipo mostrar que tipo de información tienen

    /**
     * Método abstracto que debe ser implementado por las clases hijas
     * para mostrar la información específica de cada tipo de libro.
     */
    public abstract void mostrarInformacion();

    //Clase que permite establecer si el libro está disponible
    public boolean estaDisponible() { return estado == Estado.DISPONIBLE; }

    //Clase que permite prestar un libro teniendo en cuenta su estado
    public void prestar() {
        if (estado == Estado.DISPONIBLE) {
            estado = Estado.PRESTADO;
        } else {
            System.out.println("El libro ya está prestado.");
        }
    }

    public void devolver() {
        if (estado == Estado.PRESTADO) {
            estado = Estado.DISPONIBLE;
        } else {
            System.out.println("El libro ya está disponible.");
        }
    }

    /**
     * @return El título del libro
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo El nuevo título del libro
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return El autor del libro
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @param autor El nuevo autor del libro
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * @return El género del libro
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @param genero El nuevo género del libro
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * @return El año de publicación del libro
     */
    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    /**
     * @param anioPublicacion El nuevo año de publicación del libro
     */
    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    /**
     * @return El estado actual del libro
     */
    public Estado getEstado() {
        return estado;
    }

    /**
     * @param estado El nuevo estado del libro
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }
}
