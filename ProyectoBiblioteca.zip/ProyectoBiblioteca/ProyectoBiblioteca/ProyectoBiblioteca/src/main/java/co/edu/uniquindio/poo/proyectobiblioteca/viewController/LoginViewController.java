package co.edu.uniquindio.poo.proyectobiblioteca.viewController;

import co.edu.uniquindio.poo.proyectobiblioteca.App;
import co.edu.uniquindio.poo.proyectobiblioteca.model.*;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;

public class LoginViewController {

    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private Label lblMensaje;

    private App app;

    @FXML
    private void onLogin() {
        String usuario = txtUsuario.getText();
        String contrasena = txtContrasena.getText();

        Empleado empleado = autenticar(usuario, contrasena);

        if (empleado != null) {
            lblMensaje.setText("");

            if (empleado.getUsuario() == "Administrador") {
                cargarVentana("/fxml/crudAdministrador.fxml", "Administrador");
            } else if (empleado.getUsuario() == "Bibliotecario") {
                cargarVentana("/fxml/crudBibliotecario.fxml", "Bibliotecario");
            }

        } else {
            lblMensaje.setText("Credenciales incorrectas");
        }
    }


    private void cargarVentana(String rutaFXML, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar ventana de login
            Stage actual = (Stage) txtUsuario.getScene().getWindow();
            actual.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setApp(App app) {
        this.app = app;
    }

    private Empleado autenticar(String usuario, String contrasena) {
        // Example authentication logic
        if ("admin".equals(usuario) && "password".equals(contrasena)) {
            return new Empleado("Admin", "Admin", "123", "admin@test.com", "Administrador", "1", "1") {

            };
        } else if ("bibliotecario".equals(usuario) && "password".equals(contrasena)) {
            return new Empleado("Bibliotecario", "Biblioteca", "456", "biblio@test.com", "Bibliotecario", "2", "2") {

            };
        }
        return null;
    }
}
