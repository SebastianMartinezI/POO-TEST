package co.edu.uniquindio.poo.proyectobiblioteca;

import co.edu.uniquindio.poo.proyectobiblioteca.model.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Clase principal que lanza la aplicación JavaFX y carga la pantalla de login.
 */
public class App extends Application {

    public Biblioteca biblioteca = new Biblioteca("UQ", "Calle 15 N");
    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Biblioteca UQ - Login");

        inicializarDatos(); // Datos simulados

        // Ajusta la ruta según la ubicación real del login.fxml
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/poo/proyectobiblioteca/login.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Inicializa datos de prueba (empleados y libros).
     */
    private void inicializarDatos() {
        Administrador administrador = new Administrador("Admin", "admin", "admin123", "df", "d3", "Administrador", "1");
        Bibliotecario bibliotecario = new Bibliotecario("Biblio", "biblio", "biblio123", "Bibliotecario", "dfr");


        Libro libro = new LibroFisico("Don Quijote", "Cervantes", "Novela", 1605, Estado.DISPONIBLE, 400, "Estantería A", "Planeta");

    }

    public static void main(String[] args) {
        launch(args);
    }
}
