package co.edu.uniquindio.poo.proyectobiblioteca.controller;

import co.edu.uniquindio.poo.proyectobiblioteca.model.*;

import java.util.List;

/**
 * Controlador que maneja las operaciones del Administrador en el sistema de biblioteca.
 * Este controlador actúa como intermediario entre la interfaz de usuario y la lógica
 * de negocio relacionada con las funciones administrativas.
 */
public class AdministradorController {
    private final Administrador administrador;

    public AdministradorController(Administrador administrador) {
        this.administrador = administrador;
    }

    /**
     * Registra un nuevo empleado en el sistema.
     *
     * @param empleado El empleado a registrar
     */
    public void registrarEmpleado(Empleado empleado) {
        if (empleado != null) {
            administrador.registrarEmpleado(empleado);
        }
    }

    /**
     * Elimina un empleado del sistema.
     *
     * @param empleado El empleado a eliminar
     */
    public void eliminarEmpleado(Empleado empleado) {
        if (empleado != null) {
            administrador.eliminarEmpleado(empleado);
        }
    }

    /**
     * Busca un empleado en el sistema.
     *
     * @param empleado El empleado a buscar
     * @return El empleado encontrado o null si no existe
     */
    public Empleado buscarEmpleado(Empleado empleado) {
        if (empleado != null) {
            return administrador.buscarEmpleado(empleado);
        }
        return null;
    }

    /**
     * Modifica la información de un empleado existente.
     *
     * @param empleado El empleado con la información actualizada
     */
    public void modificarEmpleado(Empleado empleado) {
        if (empleado != null) {
            administrador.modificarEmpleado(empleado);
        }
    }

    /**
     * Obtiene la lista de todos los empleados registrados.
     *
     * @return Lista de empleados
     */
    public List<Empleado> obtenerEmpleados() {
        return administrador.obtenerEmpleados();
    }

    /**
     * Registra un nuevo estudiante en el sistema.
     *
     * @param estudiante El estudiante a registrar
     */
    public void registrarEstudiante(Estudiante estudiante) {
        if (estudiante != null) {
            administrador.registrarEstudiante(estudiante);
        }
    }

    /**
     * Registra un nuevo docente en el sistema.
     *
     * @param docente El docente a registrar
     */
    public void registrarDocente(Docente docente) {
        if (docente != null) {
            administrador.registrarDocente(docente);
        }
    }

    /**
     * Registra un nuevo visitante en el sistema.
     *
     * @param visitante El visitante a registrar
     */
    public void registrarVisitante(Visitante visitante) {
        if (visitante != null) {
            administrador.registrarVisitante(visitante);
        }
    }

    /**
     * Muestra todos los empleados registrados en el sistema.
     */
    public void mostrarEmpleados() {
        administrador.mostrarEmpleados();
    }

    /**
     * Busca un usuario por su ID en el sistema.
     *
     * @param id El ID del usuario a buscar
     * @return El usuario encontrado o null si no existe
     */
    public Persona buscarUsuarioPorId(String id) {
        if (id != null) {
            return administrador.buscarUsuarioPorId(id);
        }
        return null;
    }

    /**
     * Obtiene la lista de todos los usuarios registrados.
     *
     * @return Lista de usuarios
     */
    public List<Persona> obtenerUsuarios() {
        return administrador.obtenerUsuarios();
    }

    /**
     * Muestra todos los usuarios registrados en el sistema.
     */
    public void mostrarUsuarios() {
        administrador.mostrarUsuarios();
    }

    /**
     * Obtiene la instancia del administrador.
     *
     * @return El administrador del sistema
     */
    public Administrador getAdministrador() {
        return administrador;
    }
}
