package co.edu.uniquindio.poo.proyectobiblioteca.model;

/**
 * Clase que representa un libro físico en la biblioteca.
 * Extiende la clase Libro y agrega atributos específicos para libros físicos.
 *
 * @author Biblioteca
 */
public class LibroFisico extends Libro {
    private int paginas;
    private String ubicacion;
    private String editorial;

    /**
     * Constructor para crear un nuevo libro físico.
     *
     * @param titulo          El título del libro
     * @param autor           El autor del libro
     * @param genero          El género literario del libro
     * @param anioPublicacion El año de publicación del libro
     * @param estado          El estado actual del libro
     * @param paginas         El número de páginas del libro
     * @param ubicacion       La ubicación física del libro en la biblioteca
     * @param editorial       La editorial que publicó el libro
     */
    public LibroFisico(String titulo, String autor, String genero, int anioPublicacion, Estado estado,
                       int paginas, String ubicacion, String editorial) {
        super(titulo, autor, genero, anioPublicacion, estado);
        this.paginas = paginas;
        this.ubicacion = ubicacion;
        this.editorial = editorial;
    }
    /**
     * Muestra en consola la información del libro físico.
     */
    @Override
    public void mostrarInformacion() {
        System.out.println("Libro Físico:");
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Género: " + genero);
        System.out.println("Año: " + anioPublicacion);
        System.out.println("Páginas: " + paginas);
        System.out.println("Editorial: " + editorial);
        System.out.println("Ubicación: " + ubicacion);
        System.out.println("Estado: " + estado);
        System.out.println();
    }

    /**
     * Obtiene el número de páginas del libro.
     *
     * @return el número de páginas
     */
    public int getPaginas() {
        return paginas;
    }

    /**
     * Establece el número de páginas del libro.
     *
     * @param paginas el nuevo número de páginas
     */
    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    /**
     * Obtiene la ubicación física del libro en la biblioteca.
     *
     * @return la ubicación del libro
     */
    public String getUbicacion() {
        return ubicacion;
    }

    /**
     * Establece la ubicación física del libro en la biblioteca.
     *
     * @param ubicacion la nueva ubicación del libro
     */
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    /**
     * Obtiene la editorial del libro.
     *
     * @return la editorial del libro
     */
    public String getEditorial() {
        return editorial;
    }

    /**
     * Establece la editorial del libro.
     *
     * @param editorial la nueva editorial del libro
     */
    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }
}
