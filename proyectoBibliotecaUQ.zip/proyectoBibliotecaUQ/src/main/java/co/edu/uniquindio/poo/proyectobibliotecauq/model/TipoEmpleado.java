package co.edu.uniquindio.poo.proyectobibliotecauq.model;

public enum TipoEmpleado {
    BIBLIOTECARIO,
    ADMINISTRADOR
}
