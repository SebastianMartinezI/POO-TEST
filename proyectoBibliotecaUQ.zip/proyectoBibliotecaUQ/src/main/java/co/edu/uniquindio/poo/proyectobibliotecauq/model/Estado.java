package co.edu.uniquindio.poo.proyectobibliotecauq.model;

public enum Estado {
    DISPONIBLE,
    PRESTADO
}

