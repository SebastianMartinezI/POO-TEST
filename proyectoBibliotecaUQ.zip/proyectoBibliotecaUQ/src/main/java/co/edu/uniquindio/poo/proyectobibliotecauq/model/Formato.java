package co.edu.uniquindio.poo.proyectobibliotecauq.model;

public enum Formato {
    PDF,
    EPUB,
    MOBI
}

