module co.edu.uniquindio.poo.proyectoFinal {
    requires javafx.controls;
    requires javafx.fxml;

    opens co.edu.uniquindio.poo.empresa to javafx.fxml;
    exports co.edu.uniquindio.poo.proyectoFinal;
    exports co.edu.uniquindio.poo.proyectoFinal.viewController;
    opens co.edu.uniquindio.poo.proyectoFinal.viewController to javafx.fxml;

}