package co.edu.uniquindio.poo.model;

public enum TipoEmpleado {
    BIBLIOTECARIO,
    ADMINISTRADOR
}
