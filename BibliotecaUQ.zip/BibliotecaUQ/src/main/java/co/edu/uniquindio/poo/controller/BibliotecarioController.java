package co.edu.uniquindio.poo.controller;

public class BibliotecarioController {
}
