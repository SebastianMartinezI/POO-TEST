package co.edu.uniquindio.poo.model;

public enum Formato {
    PDF,
    EPUB,
    MOBI
}
